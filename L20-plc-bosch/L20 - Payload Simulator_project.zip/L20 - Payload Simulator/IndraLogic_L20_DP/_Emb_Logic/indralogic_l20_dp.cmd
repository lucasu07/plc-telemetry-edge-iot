replace query 
file open "C:\ENG\LJD1\L20 - Serial emulator\IndraLogic_L20_DP\_Emb_Logic\IndraLogic_L20_DP.pro"
query off ok
gateway tcpip 192.168.1.101 1210
device name "Tcp/Ip (Level 2 Route)"
device parameter 1001 192.168.1.10
device parameter 1000 1200
device parameter 100 No
device parameter 1020 0
device instance L10
query off ok
query on
