﻿<?xml version="1.0" encoding="UTF-8"?>
<DiagnosisCompileData ChangeId="0" Guid="107f6272-1a4e-4fb6-b1c8-b63b98df4edf" DataFormat="2.4.0">
  <DeletedIds>
    <Change ID="0" />
  </DeletedIds>
  <Poes />
  <GlobalMachineState />
  <GlobalVariables />
</DiagnosisCompileData>